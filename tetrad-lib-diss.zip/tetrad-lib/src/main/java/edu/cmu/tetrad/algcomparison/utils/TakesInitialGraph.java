package edu.cmu.tetrad.algcomparison.utils;

/**
 * Tags an algorithm that can take an initial graph as input.
 *
 * @author jdramsey
 */
public interface TakesInitialGraph {
}
