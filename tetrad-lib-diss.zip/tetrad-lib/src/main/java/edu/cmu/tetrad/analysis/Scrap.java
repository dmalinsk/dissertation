package edu.cmu.tetrad.analysis;

import edu.cmu.tetrad.data.*;
import edu.cmu.tetrad.graph.Graph;
import edu.cmu.tetrad.graph.Node;
import edu.cmu.tetrad.search.*;
import edu.cmu.tetrad.util.DataConvertUtils;
import edu.pitt.dbmi.data.Delimiter;
import edu.pitt.dbmi.data.reader.tabular.ContinuousTabularDataFileReader;
import edu.pitt.dbmi.data.reader.tabular.TabularDataReader;

import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import static edu.cmu.tetrad.search.TimeSeriesUtils.createDifferencedData;
import static edu.cmu.tetrad.search.TimeSeriesUtils.createLagData;

/**
 * Created by dmalinsky on 7/12/17.
 */
public class Scrap {

    private void run() {

//        String path = "/Users/dmalinsky/Documents/research/data/test/1data_test629_2.1.txt";
//        String path = "/Users/dmalinsky/Documents/research/data/test/1data_test726_17.txt";
        String path = "/Users/dmalinsky/Documents/research/data/test/cvar1.txt";
        edu.pitt.dbmi.data.Delimiter delimiter = Delimiter.WHITESPACE; //' ';
        File file = new File(path);
        TabularDataReader dataReader = new ContinuousTabularDataFileReader(file, delimiter);
        DataSet data = null;
        try {
            data = (DataSet) DataConvertUtils.toDataModel(dataReader.readInData());
        } catch (IOException e) {
            e.printStackTrace();
        }

//        System.out.println(data);

        DataSet dataLag = createLagData(data, 1);
//        DataSet dataDiff = createDifferencedData(dataLag);
//        System.out.println(dataDiff);

//        DataSet dataDiffLag = createLagData(dataDiff, 1);
//        System.out.println(dataDiffLag);
//        System.out.println(dataDiffLag.getKnowledge().isInWhichTier(dataDiffLag.getVariable(0)));

//        System.out.println("original/lag/diff/lagdiff: " + data.getNumRows() + dataLag.getNumRows() + dataDiff.getNumRows() + dataDiffLag.getNumRows());

//        List<Node> variables = dataDiffLag.getVariables();
//        int i = 0;
//        List<Integer> parents = new ArrayList<>();
//        parents.add(2);
//        parents.add(3);
//        parents.add(5);
//        Node target = variables.get(i);

//        System.out.println(variables.get(i));
//        System.out.println(variables.get(3));
//        System.out.println(variables.get(5));
//        System.out.println(variables.get(11));

        /** IKnowledge knowledge = dataDiffLag.getKnowledge();
        int tierSize = knowledge.getTier(0).size();
        List<Node> regressors = new ArrayList<>();
        for (int par : parents){
            // regressors.add all lag-1 covariates *times* \beta.hat
            if(knowledge.isInWhichTier(variables.get(par)) == knowledge.isInWhichTier(target)){
                regressors.add(variables.get(par));
            } else if(knowledge.isInWhichTier(variables.get(par)) == (knowledge.isInWhichTier(target)-1)){
                int par1Lag = par - tierSize;
                regressors.add(variables.get(variables.size() - tierSize + par1Lag));

            } else {
                int parLag = par - tierSize;
                regressors.add(variables.get(parLag));
            }
//                regressors.add(variables.get(par));
        }
        **/
//        System.out.println(regressors);

//        ICovarianceMatrix cov = new CovarianceMatrix(dataLag);
//        SemBicScore semBicScore = new SemBicScore(cov);
//        IndTestFisherZ zTest = new IndTestFisherZ(cov, 0.05);

        VecmBicScore score = new VecmBicScore(dataLag, 3);
//        Node x = dataLag.getVariable(4);
//        Node y = dataLag.getVariable(0);
//        Node z = dataLag.getVariable(1);
//        int[] pars = new int[3];
//        pars[0] = 5;
//        pars[1] = 6;
//        pars[2] = 7;
//        double v = score.localScoreDiff(0, 1, pars);
//        System.out.println(v);

//        SemBicScore combScore = new SemBicScore(new CovarianceMatrix(createLagData(createDifferencedData(dataLag),1)));
//        Fges combGES = new Fges(combScore);
//        combGES.setKnowledge(score.getComb().getKnowledge());
//        Graph combGraph = combGES.search();
//        System.out.println("combGraph : " + combGraph);

        IndTestScore scoreTest = new IndTestScore(score);
//        IndTestScore semscoreTest = new IndTestScore(semBicScore);

//        System.out.println(scoreTest.isIndependent(dataLag.getVariable(5),dataLag.getVariable(2),dataLag.getVariable(8)));



        TsGFci tsGFci = new TsGFci(scoreTest,score);
//        TsFges2 tsGFci = new TsFges2(score);
//        Fges tsGFci = new Fges(score);
//        TsFges2 tsGFciSem = new TsFges2(semBicScore);
//        TsFci tsGFciSem = new TsFci(semscoreTest);
//        TsGFci tsGFciSem = new TsGFci(semscoreTest,semBicScore);
//        TsFci tsGFci = new TsFci(scoreTest);
        tsGFci.setKnowledge(dataLag.getKnowledge());
//        tsGFciSem.setKnowledge(dataLag.getKnowledge());
//        score.setPenaltyDiscount(2.0);
//        System.out.println(dataLag);
//        System.out.println(dataLag.getKnowledge());
        Graph pag = tsGFci.search();
//        Graph pagSem = tsGFciSem.search();
        System.out.println(pag);
//        System.out.println(pagSem);
//        TsFges2 FGES = new TsFges2(semBicScore);

//        System.out.println("Total Score VECM = " + FGES.getScore(pag));
//        System.out.println("Total Score SEM = " + FGES.getScore(pagSem));
//        System.out.println("Total Score VECM 2 = " + tsGFci.getScore(pag));

//        Node x = dataLag.getVariable(4);
//        Node y = dataLag.getVariable(0);
//        Node z = dataLag.getVariable(1);
//        Node[] z = new Node[] {dataLag.getVariable(1),dataLag.getVariable(7)};
//        System.out.println("Independent? " + scoreTest.isIndependent(x,y,z));
//        System.out.println("Independent semscore? " + semscoreTest.isIndependent(x,y,z));

//        int[] pars = new int[3];
//        pars[0] = 2;
//        pars[1] = 6;
//        pars[2] = 12;
//        score.localScore(0, 2);


    }

    public static void main(String... args) {
        new Scrap().run();
    }
}
