///////////////////////////////////////////////////////////////////////////////
// For information as to what this class does, see the Javadoc, below.       //
// Copyright (C) 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006,       //
// 2007, 2008, 2009, 2010, 2014, 2015 by Peter Spirtes, Richard Scheines, Joseph   //
// Ramsey, and Clark Glymour.                                                //
//                                                                           //
// This program is free software; you can redistribute it and/or modify      //
// it under the terms of the GNU General Public License as published by      //
// the Free Software Foundation; either version 2 of the License, or         //
// (at your option) any later version.                                       //
//                                                                           //
// This program is distributed in the hope that it will be useful,           //
// but WITHOUT ANY WARRANTY; without even the implied warranty of            //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             //
// GNU General Public License for more details.                              //
//                                                                           //
// You should have received a copy of the GNU General Public License         //
// along with this program; if not, write to the Free Software               //
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA //
///////////////////////////////////////////////////////////////////////////////

package edu.cmu.tetrad.performance;

import edu.cmu.tetrad.data.CovarianceMatrix;
import edu.cmu.tetrad.data.DataSet;
import edu.cmu.tetrad.data.DataUtils;
import edu.cmu.tetrad.data.ICovarianceMatrix;
import edu.cmu.tetrad.graph.*;
import edu.cmu.tetrad.search.*;
import edu.cmu.tetrad.sem.SemIm;
import edu.cmu.tetrad.sem.SemPm;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import static edu.cmu.tetrad.graph.GraphUtils.loadGraphTxt;

/**
 * @author Dan Malinsky.
 */
public class PerformanceTestsDan2 {
    private void addTruePattern() {
        int depth = -1;

        PrintStream out13;
        PrintStream out14;

        String path = "/Users/dmalinsky/Documents/tetrad/gfci.output";

        File dir0 = new File(path);
        File[] files = dir0.listFiles();

        if (files == null) throw new NullPointerException("No files in " + path);

        int n = 0;
        for (File file : files) {
            n = n+1;
            File nfile = new File(file, "dag.long.txt");
            Graph trueDag = loadGraphTxt(nfile);
            File nfilePAG = new File(file, "true.pag.long.txt");
            Graph truePAG = loadGraphTxt(nfilePAG);

//            File dir = new File(dir0, "" + n); //n+1?
//            dir.mkdir();

            try {
                out13 = new PrintStream(new File(file, "true.pattern.long.txt"));
                out14 = new PrintStream(new File(file, "true.pattern.matrix.txt"));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                throw new RuntimeException(e);
            }


            List<Node> _vars = truePAG.getNodes();
            List<Node> vars = trueDag.getNodes();
            for (Node node : vars) {
                boolean flag = true;
                for(Node node2 : _vars){
                    String name = node.getName();
                    String name2 = node2.getName();
//                    System.out.println("name = " + name);
//                    System.out.println("name2 = " + name2);
                    if(name2.equals(name)){
                        node.setNodeType(NodeType.MEASURED);
                        flag = false;
                    }
                }
                if (flag) node.setNodeType(NodeType.LATENT);
            }
//            for (Node node : vars){
//                if (!(node.getNodeType() == NodeType.MEASURED)) node.setNodeType(NodeType.LATENT);
//                System.out.println("node, type:" + node.getName() + node.getNodeType().toString());
//            }
            trueDag.setNodes(vars);
            //need to set the latents as unmeasured before doing this search!
            final IndTestDSep independenceDsep = new IndTestDSep(trueDag, false);

            Pc pc = new Pc(independenceDsep);
            pc.setVerbose(false);
            pc.setDepth(depth);

            Graph pattern = pc.search();
            out13.println("PATTERN OVER MEASURED VARIABLES");
            out13.println(pattern);
            printDanMatrix(_vars, pattern, out14);

            out13.close();
            out14.close();

        } // for file loop

    }

    private void printDanMatrix(List<Node> vars, Graph pattern, PrintStream out) {
        pattern = GraphUtils.replaceNodes(pattern, vars);
        for (int i = 0; i < vars.size(); i++) {
            for (Node var : vars) {
                Edge edge = pattern.getEdge(vars.get(i), var);

                if (edge == null) {
                    out.print(0 + "\t");
                } else {
                    Endpoint ej = edge.getProximalEndpoint(var);
                    if (ej == Endpoint.TAIL) {
                        out.print(3 + "\t");
                    } else if (ej == Endpoint.ARROW) {
                        out.print(2 + "\t");
                    } else if (ej == Endpoint.CIRCLE) {
                        out.print(1 + "\t");
                    }
                }
            }

            out.println();
        }

        out.println();
    }

    public static void main(String... args) {
        NodeEqualityMode.setEqualityMode(NodeEqualityMode.Type.OBJECT);
        System.out.println("Start ");

        new PerformanceTestsDan2().addTruePattern();
    }

}

