package edu.cmu.tetrad.analysis;

import edu.cmu.tetrad.data.CovarianceMatrix;
import edu.cmu.tetrad.data.DataSet;
import edu.cmu.tetrad.data.ICovarianceMatrix;
import edu.cmu.tetrad.graph.Edge;
import edu.cmu.tetrad.graph.Graph;
import edu.cmu.tetrad.graph.Node;
import edu.cmu.tetrad.search.*;
import edu.cmu.tetrad.util.DataConvertUtils;
import edu.pitt.dbmi.data.Delimiter;
import edu.pitt.dbmi.data.reader.tabular.ContinuousTabularDataFileReader;
import edu.pitt.dbmi.data.reader.tabular.TabularDataReader;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;

import static edu.cmu.tetrad.search.TimeSeriesUtils.createLagData;

/**
 * Created by dmalinsky on 7/12/17.
 */
public class Scrap2 {

    private void run() {

    String str = "X123:2";
    System.out.println(getNameNoLag(str));
    }

    public String getNameNoLag(Object obj) {
        String tempS = obj.toString();
        if(tempS.indexOf(':')== -1) {
            return tempS;
        } else return tempS.substring(0, tempS.indexOf(':'));
    }
    /**
    ArrayList<String> tierNames;
    Collections.sort(tierNames, new Comparator<String>() {
        @Override
        public int compare(String s1, String s2) {
            s1 = getNameNoLag(s1);
            s2 = getNameNoLag(s2);
            return s1<s2;
        }
    });**/


    public static void main(String... args) {
        new Scrap2().run();
    }
}
