package edu.cmu.tetrad.analysis;

import edu.cmu.tetrad.data.DataReader;
import edu.cmu.tetrad.data.DataSet;
import edu.cmu.tetrad.data.IKnowledge;
import edu.cmu.tetrad.graph.*;
import edu.cmu.tetrad.search.*;
import edu.cmu.tetrad.util.DataConvertUtils;
import edu.pitt.dbmi.data.Delimiter;
import edu.pitt.dbmi.data.reader.tabular.ContinuousTabularDataFileReader;
import edu.pitt.dbmi.data.reader.tabular.TabularDataReader;

import java.io.File;
import java.io.IOException;

import static edu.cmu.tetrad.search.TimeSeriesUtils.createLagData;

/**
 * Created by dmalinsky on 10/24/17.
 */
public class Scrap3 {

    private void run() {

        Graph graph = null;
        IKnowledge knowledge = null;
        DataSet data = null;
        try {
            File file1 = new File("cvar.sim/save/1/data/data.1.txt");
            File file2 = new File("cvar.sim/save/1/graph/graph.1.txt");
            graph = GraphUtils.loadGraphTxt(file2);
            File file = new File("cvar.sim/CVARknowledge.txt");
            DataReader reader = new DataReader();
            knowledge = reader.parseKnowledge(file);
            data = reader.parseTabular(file1);
        } catch (IOException e) {
            e.printStackTrace();
        }


        DataSet lagData = TimeSeriesUtils.createLagData(data,1);
//        graph = GraphUtils.replaceNodes(graph, lagData.getVariables());
        for (Node v : graph.getNodes()) {
            if (lagData.getVariable(v.getName()) == null) {
                v.setNodeType(NodeType.LATENT);
            }
        }
//        graph = GraphUtils.replaceNodes(graph, graph.getNodes());
        IndTestDSep Test = new IndTestDSep(graph, false);

//        TsFci tsFci = new TsFci(Test); // maybe set which are the vars to use as second arg?
//        tsFci.setKnowledge(knowledge);
//        tsFci.setVerbose(true);
//        Graph pag = tsFci.search();
        Graph pag2 = new TsDagToPag(new EdgeListGraph(graph)).convert();
        System.out.println(graph);
//        System.out.println(knowledge);
//        System.out.println(pag);
        System.out.println(pag2);

//        Node[] tmp = new Node[] {graph.getNode("X1:1"),graph.getNode("X5:1")};
//        System.out.println(Test.isIndependent(graph.getNode("X1"), graph.getNode("X5"), tmp));

    }

    public static void main(String... args) {
        new Scrap3().run();
    }
}
