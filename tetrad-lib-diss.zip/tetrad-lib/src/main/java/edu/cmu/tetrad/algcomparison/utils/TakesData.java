package edu.cmu.tetrad.algcomparison.utils;

/**
 * Tags a gadget that takes a data model list as argument to its constructor.
 * @author jdramsey
 */
public interface TakesData {
}
