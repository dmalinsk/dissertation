package edu.cmu.tetrad.algcomparison.independence;

import edu.cmu.tetrad.data.*;
import edu.cmu.tetrad.search.IndTestScore;
import edu.cmu.tetrad.search.IndependenceTest;
import edu.cmu.tetrad.search.SemBicScore;
import edu.cmu.tetrad.search.VecmBicScore;
import edu.cmu.tetrad.util.Parameters;

import java.util.ArrayList;
import java.util.List;

/**
 * Wrapper for VECM BIC score-based test.
 *
 * @author dmalinsky
 */
public class VecmBicTest implements IndependenceWrapper {
    static final long serialVersionUID = 23L;

    @Override
    public IndependenceTest getTest(DataModel dataSet, Parameters parameters) {
        VecmBicScore score = null;
        DataSet set = DataUtils.getContinuousDataSet(dataSet);
        score = new VecmBicScore(set,1);
        score.setPenaltyDiscount(parameters.getDouble("penaltyDiscount"));

        return new IndTestScore(score, dataSet);
    }

    @Override
    public String getDescription() {
        return "VECM BIC test";
    }

    @Override
    public DataType getDataType() {
        return DataType.Continuous;
    }

    @Override
    public List<String> getParameters() {
        List<String> params = new ArrayList<>();
        params.add("penaltyDiscount");
        return params;
    }
}
