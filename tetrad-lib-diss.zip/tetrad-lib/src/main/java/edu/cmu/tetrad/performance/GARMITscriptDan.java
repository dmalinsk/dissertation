///////////////////////////////////////////////////////////////////////////////
// For information as to what this class does, see the Javadoc, below.       //
// Copyright (C) 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006,       //
// 2007, 2008, 2009, 2010, 2014, 2015 by Peter Spirtes, Richard Scheines, Joseph   //
// Ramsey, and Clark Glymour.                                                //
//                                                                           //
// This program is free software; you can redistribute it and/or modify      //
// it under the terms of the GNU General Public License as published by      //
// the Free Software Foundation; either version 2 of the License, or         //
// (at your option) any later version.                                       //
//                                                                           //
// This program is distributed in the hope that it will be useful,           //
// but WITHOUT ANY WARRANTY; without even the implied warranty of            //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             //
// GNU General Public License for more details.                              //
//                                                                           //
// You should have received a copy of the GNU General Public License         //
// along with this program; if not, write to the Free Software               //
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA //
///////////////////////////////////////////////////////////////////////////////

package edu.cmu.tetrad.performance;

import cern.colt.matrix.DoubleMatrix2D;
import cern.colt.matrix.impl.DenseDoubleMatrix2D;
import cern.colt.matrix.linalg.Algebra;
import edu.cmu.tetrad.algcomparison.algorithm.oracle.pag.*;
import edu.cmu.tetrad.algcomparison.algorithm.oracle.pag.TsFci;
import edu.cmu.tetrad.data.CovarianceMatrix;
import edu.cmu.tetrad.data.DataSet;
import edu.cmu.tetrad.data.ICovarianceMatrix;
import edu.cmu.tetrad.graph.*;
import edu.cmu.tetrad.search.*;
import edu.cmu.tetrad.sem.Ricf;
import edu.cmu.tetrad.util.DataConvertUtils;
import edu.pitt.dbmi.data.Delimiter;
import edu.pitt.dbmi.data.reader.tabular.ContinuousTabularDataFileReader;
import edu.pitt.dbmi.data.reader.tabular.TabularDataReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static edu.cmu.tetrad.search.TimeSeriesUtils.createLagData;

//import edu.cmu.tetrad.io.TabularContinuousDataReader;

/**
 * A script for running tsFCI and/or tsGFCI on the Garrett & Mitchell data set.
 * @author Dan Malinsky
 */
public class GARMITscriptDan {

    DataSet dataLag = null;
    ICovarianceMatrix cov = null;

    private void run() {

//        double alpha = 0.05;
//        int penaltyDiscount = 1;
        int numLags = 1;

        PrintStream out1;
        PrintStream out2;
        PrintStream out3;

        File dir0 = new File("garmit.output");
        dir0.mkdirs();

        File dir = new File(dir0, "run1");
        dir.mkdir();

        try {
            out1 = new PrintStream(new File(dir, "hyperparameters.txt"));
            out2 = new PrintStream(new File(dir, "pag.long.txt"));
            out3 = new PrintStream(new File(dir, "pag.matrix.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }


//        out1.println("Alpha for GFCI = " + alpha);
//        out1.println("Penalty discount = " + penaltyDiscount);

//        String path = "/Users/dmalinsky/Documents/research/data/garmit/data_nomiss.2.txt";
        String path = "/Users/dmalinsky/Documents/research/beck_katz_2011_data/bkdata.centered.nomissX.txt";
        Delimiter delimiter = Delimiter.WHITESPACE; //' ';
        File file = new File(path);
        TabularDataReader dataReader = new ContinuousTabularDataFileReader(file, delimiter);
        DataSet data = null;
        try {
            data = (DataSet) DataConvertUtils.toDataModel(dataReader.readInData());
        } catch (IOException e) {
            e.printStackTrace();
        }

        dataLag = createLagData(data, numLags);

        cov = new CovarianceMatrix(dataLag);
//        final IndTestFisherZ FisherZTest = new IndTestFisherZ(dataLag, alpha);
//        final SemBicScore scoreGfci = new SemBicScore(cov);
//        scoreGfci.setParameter1(penaltyDiscount);

        out2.println("GFCI.PAG");

//        TsGFci tsGFCI = new TsGFci(independenceTestGFci, scoreGfci);
//        TsFci tsGFCI = new TsFci(independenceTestGFci);
//        Fges tsGFCI = new Fges(scoreGfci);
//        tsGFCI.setKnowledge(dataLag.getKnowledge());
//        tsGFCI.setVerbose(false);
//        tsGFCI.setCompleteRuleSetUsed(true);

//        edu.cmu.tetrad.search.TsFci tsFCI = new edu.cmu.tetrad.search.TsFci(FisherZTest);
//        tsFCI.setKnowledge(dataLag.getKnowledge());
//        tsFCI.setCompleteRuleSetUsed(true);
//        Graph resultGraph = tsFCI.search();
//
//        out2.println(resultGraph);
//        List<Node> _vars = resultGraph.getNodes();
//        printDanMatrix(_vars, resultGraph, out3);

//        List<Double> alphas = new ArrayList(Arrays.asList(0.40,0.39,0.38,0.37,0.36,0.35,
//                0.34,0.33,0.32,0.31,0.30,0.29,0.28,0.27,0.26,
//                0.25,0.24,0.23,0.22,0.21,0.20,0.19,0.18,0.17,
//                0.16,0.15,0.14,0.13,0.12,0.11,0.10,0.09,0.08,
//                0.07,0.06,0.05,0.04,0.03,0.02,0.01));
        List<Double> alphas = new ArrayList(Arrays.asList(0.15,0.12,0.10,0.07,0.06,0.05,0.04,0.03,0.02,0.01));
        ArrayList<Graph> graphlist = new ArrayList<>();
        ArrayList<Double> scorelist = new ArrayList<>();
        ArrayList<Double> alphalist = new ArrayList<>();
        for(double a : alphas) {
//            IndependenceTest test = new IndTestFisherZ(dataLag, a);
            IndependenceTest test = new IndTestConditionalCorrelation(dataLag, a);
            edu.cmu.tetrad.search.TsFci fci = new edu.cmu.tetrad.search.TsFci(test);
            fci.setKnowledge(dataLag.getKnowledge());
            fci.setCompleteRuleSetUsed(true);
            fci.setPossibleDsepSearchDone(true);
            fci.setMaxPathLength(-1);
            fci.setDepth(-1);
            Graph graph = fci.search();
            System.out.println("Alpha set to : " + a);
            System.out.println("Search result : " + graph);
            alphalist.add(a);
            graphlist.add(graph);
            Graph mag = MagInPag(graph);
            double score = scoreMag(mag);
            System.out.println("Score is : " + score);
            scorelist.add(score);
        }

        double minScore = Collections.min(scorelist);
        int index = scorelist.indexOf(minScore);
        double maxAlpha = alphalist.get(index);
        Graph bestGraph = graphlist.get(index);

        System.out.println("Best alpha value : " + maxAlpha);
        System.out.println("index is : " + index);
        System.out.println("Best graph : " + bestGraph);

        out1.println("Alpha for tsFCI = " + maxAlpha);
        out2.println(bestGraph);

//        System.out.println("data = " + dataLag); // why did it reorder the variables names???

        out1.close();
        out2.close();
        out3.close();
    }

    private void printDanMatrix(List<Node> vars, Graph pattern, PrintStream out) {
        pattern = GraphUtils.replaceNodes(pattern, vars);
        for (int i = 0; i < vars.size(); i++) {
            for (Node var : vars) {
                Edge edge = pattern.getEdge(vars.get(i), var);

                if (edge == null) {
                    out.print(0 + "\t");
                } else {
                    Endpoint ej = edge.getProximalEndpoint(var);
                    if (ej == Endpoint.TAIL) {
                        out.print(3 + "\t");
                    } else if (ej == Endpoint.ARROW) {
                        out.print(2 + "\t");
                    } else if (ej == Endpoint.CIRCLE) {
                        out.print(1 + "\t");
                    }
                }
            }

            out.println();
        }

        out.println();
    }

    public static void main(String... args) {
        NodeEqualityMode.setEqualityMode(NodeEqualityMode.Type.OBJECT);
        System.out.println("Start... ");
        new GARMITscriptDan().run();
        System.out.println("Done. ");
    }

    /** Creates a MAG in the equivalence class represented by a PAG.
     * First create a Tail Augmented Graph (TAG) by turning all o-> edges into -->.
     * Then orient the remaining circle component (o-o edges) into a DAG.
     * The resulting graph is a MAG in the equivalence class according to Zhang (2006, Lemma 3.3.4). **/

    public Graph MagInPag(Graph pag){
        Graph mag = new EdgeListGraphSingleConnections(pag);
        ArrayList<Edge> circleComp = new ArrayList<>();
        List<Node> nodesList = new ArrayList<>();
        for (Edge edge : mag.getEdges()) {
            if (Edges.isDirectedEdge(edge) || Edges.isUndirectedEdge(edge)
                    || Edges.isBidirectedEdge(edge)) {
                continue;
            }

            if (Edges.isPartiallyOrientedEdge(edge)){
                // create Tail Augmented Graph (TAG)
                if (edge.getEndpoint1()== Endpoint.CIRCLE){
                    mag.setEndpoint(edge.getNode2(),edge.getNode1(),Endpoint.TAIL);
                    continue;
                } else {
                    mag.setEndpoint(edge.getNode1(),edge.getNode2(),Endpoint.TAIL);
                    continue;
                }
            }

            if (Edges.isNondirectedEdge(edge)){
                circleComp.add(edge);
                Node node1 = edge.getNode1();
                Node node2 = edge.getNode2();
                if (!nodesList.contains(node1)) nodesList.add(node1);
                if (!nodesList.contains(node2)) nodesList.add(node2);
                // might be more efficient to do these with a loop?
            }
        }

//        System.out.println("Circle component is : " + circleComp);

        if (!circleComp.isEmpty()) {

            Graph pattern = new EdgeListGraphSingleConnections(nodesList);
            for (Edge edge : circleComp) {
                Node node1 = edge.getNode1();
                Node node2 = edge.getNode2();
                pattern.addUndirectedEdge(node1, node2);
            }

//            System.out.println("Pattern is : " + pattern);

            DagInPatternIterator DagIterator = new DagInPatternIterator(pattern, dataLag.getKnowledge(), false, false);
            Graph dag = DagIterator.next();

//            System.out.println("Dag is : " + dag);

            for (Edge edge : dag.getEdges()) {
                Node node1 = edge.getNode1();
                Node node2 = edge.getNode2();
                mag.removeEdge(node1, node2);
                mag.addEdge(edge);
            }
        }
//        System.out.println("Mag is : " + mag);
        return mag;
    }

    public Double scoreMag(Graph mag){
        if (cov == null) throw new NullPointerException("No covariance matrix");
        int n = dataLag.getNumRows();
        double logn = Math.log(n);
        int p = dataLag.getNumColumns();
        Ricf.RicfResult result = new Ricf().ricf2(mag, cov, 0.001);
        DoubleMatrix2D Shat = result.getShat();
//        System.out.println("Sigma hat is : " + Shat);
//        System.out.println("Number of non-zero entries = " + numNonZero(Shat));
//        int numVar = numNonZero(Shat);
        int edgeSize = mag.getEdges().size();
        return score(Shat, n, logn, p, edgeSize);
    }

    ArrayList<Integer> nlist = new ArrayList<>();
    ArrayList<Integer> plist = new ArrayList<>();
    ArrayList<Double> complexitylist = new ArrayList<>();
    // Calculates the -2BIC score. Note: assuming data is mean zero. This score is to be minimized.
    private double score(DoubleMatrix2D Shat, int n, double logn, int p, int edgeSize) {
//        DoubleMatrix2D S = cov(lagdata.getDoubleData());
        DoubleMatrix2D mat = new DenseDoubleMatrix2D(cov.getMatrix().toArray());
        double factor = ((double) n-1)/n;
        DoubleMatrix2D S = scatter(mat,factor);
        double logL = loglik(S, Shat, n);
        double complexity = (edgeSize + 2.0 * p) * logn;
        System.out.println("Loglikelihood is : " + logL);
        System.out.println("Complexity term is : " + complexity);
        nlist.add(n);
        plist.add(p);
        complexitylist.add(complexity);
//        return (-2.0 * logL + 1.0 * (numVar + p + 1.0) * logn); // increased penalty by factor of 10 // old
        return (-2.0 * logL + 1.0 * (edgeSize + 2.0 * p) * logn); // no penalty factor
    }

    ArrayList<Double> likList = new ArrayList<>();
    private double loglik(DoubleMatrix2D S, DoubleMatrix2D Shat, int n) {
        Algebra algebra = new Algebra();
        DoubleMatrix2D Si = algebra.inverse(Shat);
        DoubleMatrix2D SiS = algebra.mult(Si, S);
        double con = n * dataLag.getNumColumns() * 0.5 * Math.log(2 * Math.PI);
//        double con = 0.0;
        likList.add(-(n * 0.5) * Math.log(algebra.det(Shat)) - (n * 0.5) * algebra.trace(SiS) - con);
        return (-(n * 0.5) * Math.log(algebra.det(Shat)) - (n * 0.5) * algebra.trace(SiS) - con);
    }

    public static DoubleMatrix2D scatter(DoubleMatrix2D data, double factor) {
        for (int i = 0; i < data.rows(); i++) {
            for (int j = 0; j < data.columns(); j++) {
                data.set(i, j, data.get(i, j) * factor);
            }
        }
        return data;
    }

}

