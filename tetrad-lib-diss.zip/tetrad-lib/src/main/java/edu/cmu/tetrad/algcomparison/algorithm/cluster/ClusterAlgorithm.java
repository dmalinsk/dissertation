package edu.cmu.tetrad.algcomparison.algorithm.cluster;

/**
 * Tags an algorithm that generates clusters.
 *
 * @author jdramsey
 */
public interface ClusterAlgorithm {
}
