///////////////////////////////////////////////////////////////////////////////
// For information as to what this class does, see the Javadoc, below.       //
// Copyright (C) 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006,       //
// 2007, 2008, 2009, 2010, 2014, 2015 by Peter Spirtes, Richard Scheines, Joseph   //
// Ramsey, and Clark Glymour.                                                //
//                                                                           //
// This program is free software; you can redistribute it and/or modify      //
// it under the terms of the GNU General Public License as published by      //
// the Free Software Foundation; either version 2 of the License, or         //
// (at your option) any later version.                                       //
//                                                                           //
// This program is distributed in the hope that it will be useful,           //
// but WITHOUT ANY WARRANTY; without even the implied warranty of            //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             //
// GNU General Public License for more details.                              //
//                                                                           //
// You should have received a copy of the GNU General Public License         //
// along with this program; if not, write to the Free Software               //
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA //
///////////////////////////////////////////////////////////////////////////////

package edu.cmu.tetrad.algcomparison.examples;

import edu.cmu.tetrad.algcomparison.Comparison;
import edu.cmu.tetrad.algcomparison.algorithm.Algorithms;
import edu.cmu.tetrad.algcomparison.algorithm.oracle.pag.*;
import edu.cmu.tetrad.algcomparison.algorithm.oracle.pattern.*;
import edu.cmu.tetrad.algcomparison.independence.FisherZ;
import edu.cmu.tetrad.algcomparison.independence.SemBicTest;
import edu.cmu.tetrad.algcomparison.score.SemBicScore;
import edu.cmu.tetrad.algcomparison.score.VecmBicScore;
import edu.cmu.tetrad.algcomparison.independence.VecmBicTest;
import edu.cmu.tetrad.data.DataReader;
import edu.cmu.tetrad.data.DataSet;
import edu.cmu.tetrad.data.IKnowledge;
import edu.cmu.tetrad.search.TimeSeriesUtils;
import edu.cmu.tetrad.search.TsFges2;
import edu.cmu.tetrad.util.Parameters;
import edu.cmu.tetrad.algcomparison.statistic.*;

import java.io.File;
import java.io.IOException;

/**
 * An example script to load in data sets and graphs from files and analyze them. The
 * files loaded must be in the same format as
 * </p>
 * new Comparison().saveDataSetAndGraphs("comparison/save1", simulation, parameters);
 * </p>
 * saves them. For other formats, specialty data loaders can be written to implement the
 * Simulation interface.
 *
 * @author jdramsey
 */
public class ExampleCompareFromFiles {
    public static void main(String... args) {
        Parameters parameters = new Parameters();

        // Can leave the simulation parameters out since
        // we're loading from file here.
        parameters.set("alpha", 0.05);
        parameters.set("penaltyDiscount", 1.0);
        parameters.set("numRuns", 100);

        Statistics statistics = new Statistics();

//        statistics.add(new ParameterColumn("avgDegree"));
        statistics.add(new ParameterColumn("sampleSize"));
        statistics.add(new AdjacencyPrecision());
        statistics.add(new AdjacencyRecall());
        statistics.add(new ArrowheadPrecision());
        statistics.add(new ArrowheadRecall());
        statistics.add(new MathewsCorrAdj());
        statistics.add(new MathewsCorrArrow());
        statistics.add(new F1Adj());
        statistics.add(new F1Arrow());
        statistics.add(new SHD());
        statistics.add(new ElapsedTime());

        statistics.setWeight("AP", 1.0);
        statistics.setWeight("AR", 0.5);
        statistics.setWeight("AHP", 1.0);
        statistics.setWeight("AHR", 0.5);

        Algorithms algorithms = new Algorithms();

        /** IKnowledge knowledge = null;
        try {
//            File file1 = new File("cvar.sim/save/1/data/data.1.txt");
//            DataReader reader = new DataReader();
//            reader.setVariablesSupplied(true);
//            reader.setMaxIntegralDiscrete(parameters.getInt("maxDistinctValuesDiscrete"));
//            DataSet temp = reader.parseTabular(file1);
//            DataSet lagData = TimeSeriesUtils.createLagData(temp, 1);
//            knowledge = lagData.getKnowledge();
            File file = new File("cvar.sim/CVARknowledge.txt");
            DataReader reader = new DataReader();
            knowledge = reader.parseKnowledge(file);
        } catch (IOException e) {
            e.printStackTrace();
        } **/

//        algorithms.add(new Fci(new FisherZ()));
//        algorithms.add(new Cpc(new FisherZ()));
//        algorithms.add(new PcStable(new FisherZ()));
//        algorithms.add(new CpcStable(new FisherZ()));
        algorithms.add(new TsGfci(new VecmBicTest(), new VecmBicScore()));
        algorithms.add(new TsGfci(new SemBicTest(), new SemBicScore()));
//        algorithms.add(new Gfci(new FisherZ(), new SemBicScore()));
//        algorithms.add(new Gfci(new FisherZ(), new VecmBicScore()));
//        algorithms.add(new Fges(new VecmBicScore()));
//        algorithms.add(new Fges(new SemBicScore()));

        Comparison comparison = new Comparison();
        comparison.setShowAlgorithmIndices(false);
        comparison.setShowSimulationIndices(false);
        comparison.setSortByUtility(true);
        comparison.setShowUtilities(true);
        comparison.setParallelized(true);

        comparison.setSaveGraphs(true);
        comparison.compareFromFiles("cvar.sim500", algorithms, statistics, parameters);
    }
}




